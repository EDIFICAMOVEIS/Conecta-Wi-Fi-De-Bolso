When updating the Conect Wi-Fi project:
- Always check if the README.md needs to be updated
- Update the "Última atualização" date to the current date
- Add new sections to the README if major features are added
- Update the "Características" section if design or functionality changes significantly
- Update plan information when pricing or packages change
- Keep the README concise and accurate with the current state of the project
